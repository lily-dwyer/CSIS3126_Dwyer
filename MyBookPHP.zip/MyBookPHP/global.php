<?php

//common content used on every page

$connection = mysqli_connect("localhost","root","root","mybooks") or die("Unable to connect to database");
